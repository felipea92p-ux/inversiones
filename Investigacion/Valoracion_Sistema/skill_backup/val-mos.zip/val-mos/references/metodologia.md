# Metodología de valoración — VAL-MOS v1 (calibrada 1-2 jul-2026)

## PASO 1 (obligatorio): DCF INVERSO — informativo, sin veto
Antes de calcular nada: ¿qué crecimiento de owner earnings implica el precio DE HOY? (resolver g
con WACC construido y terminal fijo). Veredicto contra base rates (historia propia de la empresa,
base rates de crecimiento de Mauboussin por tamaño de empresa):
- **BAJAS** — el precio implica menos de lo que la empresa ya demuestra → posible regalo.
- **RAZONABLES** — en línea con historia/base rates.
- **HEROICAS** — por encima de base rates sin razón estructural → **+10pp al MoS exigido** (no veta).

## PASO 2: PWFV-Valor (el ancla ÚNICA de zonas y MoS)
**Dos cifras separadas — nunca mezclarlas en un solo número:**
1. **PWFV-Valor** = lo que VALE. Blend: **DCF sobre owner earnings (×2) + EPV de Greenwald (×1)**.
   - **Owner earnings**: FCF ajustado restando **100% del SBC siempre** (Damodaran puro, sin
     excepciones); normalizar absorciones discrecionales de balance (credit books, float) con
     puente explícito; anclar al extremo conservador.
   - **DCF**: horizonte 10 años, 3 escenarios probabilísticos (típico 30-35/45-50/20-25) cada uno
     con su narrativa de 3 líneas (test narrativa-números: si no se puede contar, el número no va).
     WACC construido input a input (rf 10Y actual + beta×ERP + prima país por mix de ingresos;
     nunca WACC de utility para growth EM). **Checks anti-Damodaran automáticos:** g terminal ≤
     min(3%, rf); margen año 10 ≤ máximo histórico propio; reinversión coherente con g (g = ROIC ×
     tasa de reinversión).
   - **EPV (Greenwald)** = NOPAT normalizado / WACC — el SUELO sin crecimiento. Métrica derivada:
     **peso del crecimiento = 1 − EPV/precio**. Si >60% del precio depende de crecimiento futuro →
     solo comprable en zona GANGA + asimetría aprobada.
2. **Banda de Pricing** = lo que el mercado suele PAGAR (contexto, no ancla): PER justificado,
   EV/EBITDA y P/FCF vs historia propia de 3-5 años, señalando denominadores deprimidos/inflados.
   **PEG: peso 0** — se reporta solo como contexto (herencia Lynch; Damodaran demuestra que sesga
   contra alta calidad).
- **Cíclicas** (semis incluidos cuando aplique): sustituir earnings TTM por **mid-cycle** (margen
  medio de 10 años × ingresos actuales) si el margen actual > percentil 80 histórico. PER bajo con
  márgenes récord = presunción de PEAK earnings (ver trampas.md).
- **Sensibilidad**: heatmap WACC × g terminal; el rango honesto se reporta SIEMPRE (banda, no
  falsa precisión).

## PASO 3: Zonas de precio (ancladas SOLO al PWFV-Valor)
| Zona | Rango vs PWFV-Valor |
|---|---|
| GANGA FUERTE | ≥25% descuento |
| OPORTUNIDAD | 15–25% descuento |
| PRECIO JUSTO | ±15% |
| CARO | 15–35% premium |
| BURBUJA | >35% premium |

## PASO 4: Escalera MoS por tier QG + candados
**Escalera (descuento mínimo vs PWFV-Valor para COMPRAR):**
| Tier QG | MoS mínimo | Techo de múltiplo (owner earnings normalizados, SBC restado) |
|---|---|---|
| Núcleo (≥85) | **≥15%** | **35x** |
| Alta convicción (75-84) | **≥25%** | **30x** |
| Sólida (65-74) | **≥35%** | **25x** |
| Watchlist (<65) | **NO SE COMPRA** | — |

**Candados (todos duros):**
- **Techo de múltiplo escalonado** (tabla): por encima NO hay compra sin importar la calidad — la
  calidad no protege del sobrepago (MSFT 2000: 14-16 años; KO 1998: ~15 años; Nifty Fifty).
- **EPV**: peso del crecimiento >60% del precio → exigir zona GANGA + asimetría.
- **VÍA SIN CRISIS (Smith/Kantesaria), SOLO Núcleo:** entrada válida sin MoS clásico si
  [FCF yield ≥ bono 10Y] Y [FCF yield + crecimiento FCF ≥ 11-12%], sujeta igual al techo de 35x.
  **NO puede usarse para aumentar posiciones que ya superan 20% del NAV** — solo iniciar/completar
  Núcleo subponderado; si el gate pasa pero la posición está sobredimensionada → señal = SOSTENER.
- **SOBRECARGO TURNAROUND:** si la tesis requiere reversión de márgenes/ROIC → MoS ≥40% + peso
  ≥50% al escenario pesimista. Aplica SOLO a deterioro CÍCLICO confirmado por el detector dentro
  del universo QG (el base rate ~30% de Mauboussin se calibró en turnarounds genuinos, no en
  compounders con tropiezo — el % exacto se recalibrará con datos propios).
- **ASIMETRÍA (Pabrai), último filtro universal:** upside(escenario base) / downside(escenario
  pesimista) **≥3:1** con los 3 escenarios ya calculados. Nunca anula un veto del detector.
- **OVERLAY BURBUJA SECTORIAL:** si el sector muestra ≥3 señales (P/E fwd sectorial >40-60x, P/S
  >10-20x en no rentables, >70% IPOs sin beneficios, volumen IPO/SPAC récord, concentración top-7
  del índice >30%, FCF negativo generalizado) → MoS extra o abstención aunque la empresa pase todo.

## Deratings por tipos de interés
La zona se mide contra el PWFV-Valor recalculado con WACC ACTUALIZADO (rf de hoy). Un derating
por subida de tipos no es descuento — es el nuevo valor justo.
